# Controle de Estoque de TI Empresarial

📦 Aplicativo desenvolvido em **React Native** (Expo) para gerenciamento de estoque de equipamentos de TI em empresas. Permite cadastrar produtos, categorizar itens, registrar transações (entradas e saídas) e acompanhar o histórico de movimentações, além de visualizar estatísticas em gráficos.

---

## 🎯 Objetivo

O objetivo deste projeto é fornecer uma **solução simples e eficiente** para:

- Controlar o estoque de equipamentos de TI de forma organizada;
- Evitar falta ou excesso de equipamentos;
- Facilitar a visualização de dados e movimentações;
- Oferecer histórico detalhado de transações para auditoria.

---

## ⚙️ Funcionalidades

1. **Cadastro de produtos**
   - Inserir nome, categoria, quantidade, localização e descrição.
   - Criar categorias personalizadas caso não existam.
   - Interface intuitiva com seleção de categorias.

2. **Gestão de categorias**
   - Criar novas categorias de produtos diretamente na tela de cadastro.
   - Visualizar a lista de categorias existentes.

3. **Registro de transações**
   - Registrar **entrada** ou **saída** de produtos.
   - Registrar quantidade e observações.
   - Atualiza automaticamente o estoque do produto.

4. **Visualização do estoque**
   - Tela inicial mostrando **total de produtos**.
   - Gráfico de barras mostrando a quantidade de produtos por categoria.

5. **Histórico de transações**
   - Lista todas as transações registradas.
   - Detalhes incluem tipo (entrada/saída), quantidade, produto, observação e data/hora.
   - Diferencia visualmente entradas e saídas.

6. **Atualização automática**
   - Ao adicionar produto ou registrar transação, a tela inicial atualiza gráficos e totais automaticamente.

---

## 🛠 Tecnologias utilizadas

- **React Native** (Expo)
- **TypeScript**
- **SQLite** (via `expo-sqlite`) para armazenamento local
- **React Navigation** (stack navigation)
- **react-native-gifted-charts** para gráficos
- **UUID** para geração de IDs quando necessário

---

## 💻 Instalação e execução local

### Pré-requisitos

- Node.js >= 18
- npm ou yarn
- Expo CLI (global)
  ```bash
  npm install -g expo-cli
